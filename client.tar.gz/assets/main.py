import sys
import json
import asyncio
import pygame

# --- JSONBIN EINSTELLUNGEN ---
BIN_ID = "6a7b6794da38895dfed6f73c"

# Prüft, ob wir im Browser sind
is_browser = sys.platform in ("emscripten", "wasi")

# Spieler-Variablen
player_x, player_y = 100, 100
player2_x, player2_y = 100, 100
player_speed = 5
player_size = 30
player2_adress = "Warte auf P2..."
running = True

# Pygame Setup (ohne Sound, um Browser-Fehler zu vermeiden)
pygame.display.init()
pygame.font.init()
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 28)


def zeige_status(text, farbe=(255, 255, 255)):
    """Zeigt Text auf dem Bildschirm an und aktualisiert das Fenster sofort (Verhindert Blackscreens)."""
    screen.fill((30, 40, 60))
    txt = font.render(text, True, farbe)
    screen.blit(txt, (40, 40))
    pygame.display.flip()


# Callback für Browser-Websockets
def browser_on_message(event):
    global player2_x, player2_y, player2_adress
    try:
        msg = str(event.data)
        if msg.count(",") == 2:
            parts = msg.split(",")
            player2_adress = parts[0].strip()
            player2_x = int(parts[1].strip())
            player2_y = int(parts[2].strip())
    except:
        pass


async def main():
    global player_x, player_y, player2_x, player2_y, player2_adress, running

    await asyncio.sleep(0)  # Zwingend notwendig für Pygbag!

    zeige_status("Schritt 1: Lade Matchmaker (JSONBin)...")
    await asyncio.sleep(0.1)

    HOST_DOMAIN = None

    # --- SCHRITT 1: SERVER-IP HOLEN ---
    if is_browser:
        import platform
        window = platform.window
        try:
            # Nutze natives JS Fetch (ohne eval-Fehleranfälligkeit)
            resp = await window.fetch(f"https://api.jsonbin.io/v3/b/{BIN_ID}/latest")
            js_data = await resp.json()
            # JS-Objekt sicher zu Python-Dict machen
            js_string = window.JSON.stringify(js_data)
            py_data = json.loads(js_string)
            HOST_DOMAIN = py_data['record']['host']
        except Exception as e:
            print(f"Browser Fetch Fehler: {e}")
    else:
        import urllib.request
        try:
            url = f"https://api.jsonbin.io/v3/b/{BIN_ID}/latest"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                res = json.loads(response.read().decode())
                HOST_DOMAIN = res['record']['host']
        except Exception as e:
            print(f"PC Fetch Fehler: {e}")

    if not HOST_DOMAIN:
        zeige_status("FEHLER: Kein Server in JSONBin gefunden!", (255, 100, 100))
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            await asyncio.sleep(0.05)
        return

    # --- SCHRITT 2: WEBSOCKET VERBINDUNG ---
    ws_url = f"wss://{HOST_DOMAIN}"
    zeige_status(f"Schritt 2: Verbinde mit {ws_url} ...")
    await asyncio.sleep(0.1)

    ws_local = None
    browser_ws = None
    adress = "Player1"

    if is_browser:
        import platform
        try:
            browser_ws = platform.window.WebSocket.new(ws_url)
            browser_ws.onmessage = browser_on_message

            # Wir warten max. 5 Sekunden, bis der Socket wirklich OPEN (1) ist
            verbunden = False
            for _ in range(50):
                if browser_ws.readyState == 1:
                    verbunden = True
                    break
                await asyncio.sleep(0.1)  # Gibt dem Browser Zeit zum Verbinden!

            if not verbunden:
                zeige_status("FEHLER: WebSocket Server antwortet nicht!", (255, 100, 100))
                while running:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False
                    await asyncio.sleep(0.05)
                return

        except Exception as e:
            zeige_status(f"WebSocket Fehler: {e}", (255, 100, 100))
            await asyncio.sleep(3)
    else:
        import websockets
        try:
            ws_local = await websockets.connect(ws_url)
            adress = await ws_local.recv()

            async def receive_messages():
                global player2_x, player2_y, player2_adress
                try:
                    async for message in ws_local:
                        if message and message.count(",") == 2:
                            parts = message.split(",")
                            player2_adress = parts[0].strip()
                            player2_x = int(parts[1].strip())
                            player2_y = int(parts[2].strip())
                except:
                    pass

            asyncio.create_task(receive_messages())
        except Exception as e:
            zeige_status(f"PC WebSocket Fehler: {e}", (255, 100, 100))
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                await asyncio.sleep(0.05)
            return

    zeige_status("SPIEL STARTET!")
    await asyncio.sleep(0.5)

    # --- SCHRITT 3: HAUPT-SPIELSCHLEIFE ---
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: player_x -= player_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: player_x += player_speed
        if keys[pygame.K_UP] or keys[pygame.K_w]: player_y -= player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: player_y += player_speed

        # Rand-Kollision
        if player_x < 0: player_x = 0
        if player_x > screen_width - player_size: player_x = screen_width - player_size
        if player_y < 0: player_y = 0
        if player_y > screen_height - player_size: player_y = screen_height - player_size

        # Sende Position
        werte = f"{adress}, {player_x}, {player_y}"
        if is_browser:
            if browser_ws and browser_ws.readyState == 1:
                browser_ws.send(str(werte))
        else:
            try:
                await ws_local.send(werte)
            except:
                pass

        # Alles zeichnen
        screen.fill((30, 40, 60))

        # Unser eigener Spieler (Rot)
        pygame.draw.rect(screen, (230, 50, 50), (player_x, player_y, player_size, player_size))

        # Minimap & Gegner (Grün)
        pygame.draw.rect(screen, (45, 60, 90), (600, 0, 200, 150))
        pygame.draw.rect(screen, (50, 230, 50), (600 + int(player2_x / 4), int(player2_y / 4), 12.5, 12.5))

        # Text für P2 einblenden
        txt_p2 = font.render(f"P2: {player2_adress}", True, (200, 200, 200))
        screen.blit(txt_p2, (610, 160))

        pygame.display.flip()
        clock.tick(60)

        # WICHTIG FÜR DEN BROWSER: Erlaubt das Neuladen des Tabs
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())